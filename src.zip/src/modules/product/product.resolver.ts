import { Resolver, Query, Mutation, Args } from '@nestjs/graphql';
import { ProductService } from './product.service';
import { Product } from './schema/product.schema';
import { CreateProductInput } from './dto/product.dto';

@Resolver(() => Product)
export class ProductResolver {
  constructor(
    private readonly productService: ProductService,
    // private readonly logger: LoggerService,
  ) {
    // this.logger.setContext(ProductResolver.name);
  }

  @Mutation(() => Product)
  async createProduct(@Args('input') input: CreateProductInput) {
    // this.logger.log(`Creating product: ${JSON.stringify(createProductDto)}`, 'createProduct');
    return this.productService.create(input);
  }
}
