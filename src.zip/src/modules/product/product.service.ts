import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Product } from './schema/product.schema';
import { CreateProductInput } from './dto/product.dto';

@Injectable()
export class ProductService {
  constructor(
    @InjectModel(Product.name) private productModel: Model<Product>,
    // private readonly logger: LoggerService,
  ) {
    // this.logger.setContext(ProductService.name);
  }

  async create(createProductInput: CreateProductInput): Promise<Product> {
    const createdProduct = new this.productModel(createProductInput);
    return createdProduct.save();
  }

  async findAll(): Promise<Product[]> {
    // this.logger.log('Fetching all products', 'findAll');
    const products = await this.productModel.find().exec();
    // this.logger.log(`Products: ${JSON.stringify(products)}`, 'findAll');
    return products;
  }
}
